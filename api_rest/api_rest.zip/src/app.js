const express = require('express');
const morgan = require('morgan');

const app =express();

//config
app.set('port', 3000);
app.set('json spaces', 2)

//middle
app.use(morgan('dev'));
app.use(express.urlencoded({extended:false}));
app.use(express.json());

//route
app.use(require('./routes/index'));
app.use(require('./routes/products'));

//Iniciar server
app.listen(app.get('port'), () => {
    console.log(`Server on port ${app.get('port')}`);
});
